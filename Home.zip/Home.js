
 import React,{useState,Component} from 'react'
 import {Redirect} from 'react-router';
 import './home.css';

 
 function Home() {

      const [auth,setAuth]=useState(false);
    if(auth){
        return <Redirect to="/log" />
    }
        return (
           
            <div>
                <nav>
                    <div class="logo">
                        <p>Train Ticket Booking</p>
                    </div>
                    <ul>
                        <li><a href="" className="active">Home</a></li>
                        <li><a href="">Train Details</a></li>
                        <li><a href="">Register Foam</a></li>
                        <li><a href="" onClick={()=>setAuth(true)} >Login</a></li>
                        <li><a href="">Logout</a></li>
                        
                    </ul>
                </nav>
                

                
            </div>
            
            
        )
    }


export default Home


    