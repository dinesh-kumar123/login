import React,{useState} from 'react'
import {Redirect} from 'react-router';
import './Login.css';


function Login() {
    const [data,setData] =useState({
        username:'',
        password:''
    })
    const {username,password} = data;
    const changeHandler = e =>{
        setData({...data,[e.target.name]:[e.target.value]})
    }
    const submitHandler = e =>{
        e.preventDefault()
        console.log(data)
    }
    const [auth,setAuth]=useState(false);
    if(auth){
        return <Redirect to="/signup" />
    }
    const [home,sethome]=useState(false);
    if(home){
        return <Redirect to="/home"/>
        
    }
    return (
        <div className=".demo">
            <form onSubmit={submitHandler}>
                <div className="log">
                    <label for="name">USERNAME</label>
                <input type="text" name="username" placeholder="EnterUsername"value={username} onChange={changeHandler}/><br />
                </div>
                <div className="text">
                    <label for="password">PASSWORD</label>
                <input type="password" name="password" placeholder="EnterPassword" value={password} onChange={changeHandler}/><br />
                </div>
                <div className="sub">
                <input type="submit" name="submit" onClick={()=>sethome(true)} />
                <div class="signup_link">
                   Not a member?<a href="#" onClick={()=>setAuth(true)}>Signup</a>
               </div>
               </div>
            </form>
        </div>
    )
}

export default Login
