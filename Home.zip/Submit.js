import React,{useState} from 'react' 

import axios from 'axios';
import './Login.css';

function Submit() {
    const [data,setData] = useState({
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
    })
    const{username,email,password,confirmPassword} =data;
    const changeHandler = e =>{
        setData({...data,[e.target.name]:e.target.value})
    }
    const submitHandler = e =>{
        e.preventDefault();
        axios.post("https://dinesh-477a6-default-rtdb.firebaseio.com/register",
        data).then(()=> alert("submitted successfully"))
        if(username.length <= 5){
            alert("username must be at least 5 charcter");
        }
        
        else if(password!==confirmPassword) {
            alert("passwords are not matching");
            }
            else{
                console.log(data)
            }

        
    }
    
    return (
        <div className="demo">
        
          
            <center>
            <form autoComplete="off" onSubmit={submitHandler}>
                <div className="User">
                <label for="name">USERNAME</label>
                <input type="text" name="username" placeholder="Username" value={username} onChange={changeHandler} /><br />
                </div>
                <div className="mail">
                <label for="email">EMAIL</label>
                <input type="email" name="email" placeholder="Enter Mail" value={email} onChange={changeHandler}/><br />
                </div>
                <div className="pws">
                <label for="password">PASSWORD</label>
                <input type="password" name="password" placeholder=" Type password" value={password} onChange={changeHandler}/><br />
                </div>
                <div className="cpws">
                <label for="confirm pass">CONFIRMPASS</label>
                <input type="password" name="confirmPassword" placeholder="confirm your password" value={confirmPassword} onChange={changeHandler}/><br />
                </div>
            {password !== confirmPassword ? <p style={{"color":"red"}}>passwords not matching</p>:null}
            <div className="sub">
               <input type="submit" name="submit"  /><br />

              </div> 
            </form>
            </center>

            


        </div>
        
    )
}

export default Submit
